
	
//Login Validation
$(document).ready(function(){
	$('form[id="form4"]').validate({
		rules:{
			section: "required",
		ans:{
			required: true,
		}
		},
		messages:{
			section: "Please select a question",
		
		ans:{
			required: "Answer is required"
		}
	},

	submitHandler:function(form){
		form.submit();
		}
	}); 
	
	//flip-flop of forgot_password
$('.message a').click(function(){
$('form').animate({height:"toggle",opacity:"toggle"},"slow");
});
	
});
