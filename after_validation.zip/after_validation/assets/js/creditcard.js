//to select credit or debit

function SelectRedirect()
{
       switch(document.getElementById('s1').value)
{
case "credit":
window.location="creditcard.html";
break;

case "debit":
window.location="debitcard.html";
break;
}
}

//validation on credit and debit
$(document).ready(function(){

$('form[id="payment_form"]').validate({

rules:{
num:{required:true,minlength:16,maxlength:16},
date: "required",
cvv:{required:true,minlength:3,maxlength:3},
name:"required"

},
messages:{
num:{required:"Card number is required",minlength:"Invalid card number",maxlength:"Invalid card number"},
   date: "Date is required",
cvv:{required:"cvv is required",minlength:"Invalid cvv",maxlength:"Invalid cvv"},
name:"Name is required"
},

submitHandler:function(form){
form.submit();
}

});

});