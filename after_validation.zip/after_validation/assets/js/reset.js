
$(document).ready(function(){
	$('form[id="form_reset"]').validate({
		

		rules:{
			v1: {
				required:true,
				minlength:5
			},
			v2:{
				required:true,
				minlength: 5,
				equalTo : '[name="v1"]'
				}
			
		},
			


		messages:{
			v1:{
				required:"Enter your new Password",
				minlength:"Password length must be 5 characters",
			},
			
			v2:{
				required:"Enter your new Password",
				equalTo:"Password Mismatch",
				minlength:"Password length must be 5 characters",
			}
		},
		
	submitHandler:function(form){
	form.submit();
		}
	}); 
	

	
});
