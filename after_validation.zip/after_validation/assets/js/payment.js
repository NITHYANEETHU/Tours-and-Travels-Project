function SelectRedirect()
{
       switch(document.getElementById('s1').value)
{
case "credit":
window.location="creditcard.html";
break;

case "debit":
window.location="debitcard.html";
break;
}
}