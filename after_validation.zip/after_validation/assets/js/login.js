//flip-flop of login and sign-up
$('.message a').click(function(){
$('form').animate({height:"toggle",opacity:"toggle"},"slow");
});
	
//Login Validation
$(document).ready(function(){
	$('form[id="form2"]').validate({
		rules:{
			uname: "required",
		pass:{
			required: true,
		}
		},
		messages:{
			uname: "UserID is required",
		pass:{
			required: "Password is required"
		}
	},

	submitHandler:function(form){
		form.submit();
		}
	}); 
});

//Signin validation
$(document).ready(function(){
	$('form[id="form1"]').validate({
		rules:{
			user: {
				required:true,
				minlength:5,
				maxlength:10,
			},
			email: {
				required:true,
				email:true,
			},
			password: {
				required: true,
				minlength:5
			},
			cpass: {
				required: true,
				minlength: 5,
				equalTo : '[name="password"]'
			},
			 date: {
				required: true,
				date: true
			},
			phone:{
				required:true,
				minlength:10,
				maxlength:10,
			},
			question: {
				required:true
			},
			answer: "required",
		},
		
		messages:{
			user:{
				required:"Please provide valid name",
				minlength:"Minimum 5 characters in length",
				maxlength:"Maximum 10 characters in length",
			},
			email:{
				required:"Invalid email"
			},
			password:{
				required: "Invalid Password",
				minlength:"Password length should be atleast 5 characters",
			},
			cpass:{
				required:"Enter confirm password",
				minlength:"Password length should be atleast 5 characters",
				equalTo:"Password doesn't match",
			},
			date: {
				required:"DOB is required",
			},
			phone:{
				required:"Enter your contact no.",
				minlength:"Contact no. must be 10 digit",
				maxlength:"Contact no. must be 10 digit",
			},
			type:{
				required: "Please provide the question type",
			},
			answer:"Please provide the Answer",
			
		},
		submitHandler:function(form){
			form.submit();
		}
	});
});  

 