 $(document).ready(function() {
 
  $("form[id='package_form']").validate({
	  rules:{
          field4:"required",
		  field5:"required",
		  field6:"required",
		  field7:"required",
		  from_date:"required",
		  to_date:"required",
		  no_of_travellers:"required"
        },
		messages:{
			field4:"Please select an option",
			field5:"Please select an option",
			field6:"Please select an option",
			field7:"Please select an option",
			from_date:"From date is required",
		    to_date:"To date is required",
			no_of_travellers:"Please enter no of travellers"
        },
submitHandler:function(form){form.button();}
      });	
});

  